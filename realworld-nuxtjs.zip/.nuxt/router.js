import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _3fc55129 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _8f3282c4 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _54a95d8a = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _ae2218ec = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _062f8e62 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _33f6776c = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _e08d9252 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _3fc55129,
    children: [{
      path: "/",
      component: _8f3282c4,
      name: "home"
    }, {
      path: "/login",
      component: _54a95d8a,
      name: "login"
    }, {
      path: "/register",
      component: _54a95d8a,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _ae2218ec,
      name: "profile"
    }, {
      path: "/settings",
      component: _062f8e62,
      name: "settings"
    }, {
      path: "/editor/:slug?",
      component: _33f6776c,
      name: "editor"
    }, {
      path: "/article/:slug?",
      component: _e08d9252,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
